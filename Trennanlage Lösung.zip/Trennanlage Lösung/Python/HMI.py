# -*- coding: utf-8 -*-
from scriptengine import*
import os

scriptfile = os.path.dirname(__file__)
projectfile = os.path.join(scriptfile, "automatische Projektgenerierung")

if projects.primary:
    prj = projects.primary
else:
    prj = projects.open(projectfile)

apl = prj.active_application
visu = apl.create_visualobject("Visualisierung_Trennanlage")

visu.begin_modify()
elementlist = visu.visual_element_list

# --- Rahmen 1 wird hinzugefügt: SBL_Valve ---
rahmen_ref_0 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_0 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_0.set_frame_references([rahmen_ref_0])

rahmen_obj_0.set_property("Position.X", 70)
rahmen_obj_0.set_property("Position.Y", 30)
rahmen_obj_0.set_property("Position.Breite", 85)
rahmen_obj_0.set_property("Position.Höhe", 60)

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS100'")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y100")

# --- Rahmen 2 wird hinzugefügt: SBL_AIN ---
rahmen_ref_1 = visu.create_frame_reference("AutomationLibrary2.SBL_AIN")
rahmen_obj_1 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_1.set_frame_references([rahmen_ref_1])

rahmen_obj_1.set_property("Position.X", 245)
rahmen_obj_1.set_property("Position.Y", 25)
rahmen_obj_1.set_property("Position.Breite", 230)
rahmen_obj_1.set_property("Position.Höhe", 70)

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_AIN.Text",
    "'FIC300'")

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_AIN.Unit",
    "'l/h'")

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_AIN.AIN",
    "F300")

# --- Rahmen 3 wird hinzugefügt: SBL_ControlValve ---
rahmen_ref_2 = visu.create_frame_reference("AutomationLibrary2.SBL_ControlValve")
rahmen_obj_2 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_2.set_frame_references([rahmen_ref_2])

rahmen_obj_2.set_property("Position.X", 577)
rahmen_obj_2.set_property("Position.Y", 20)
rahmen_obj_2.set_property("Position.Breite", 100)
rahmen_obj_2.set_property("Position.Höhe", 80)

rahmen_obj_2.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_ControlValve.Text",
    "'YC300'")

rahmen_obj_2.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_ControlValve.AOUT",
    "Y300")

# --- Rahmen 4 wird hinzugefügt: SBL_Valve ---
rahmen_ref_3 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_3 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_3.set_frame_references([rahmen_ref_3])

rahmen_obj_3.set_property("Position.X", 780)
rahmen_obj_3.set_property("Position.Y", 30)
rahmen_obj_3.set_property("Position.Breite", 85)
rahmen_obj_3.set_property("Position.Höhe", 60)

rahmen_obj_3.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS200'")

rahmen_obj_3.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y200")

# --- Rahmen 5 wird hinzugefügt: FPL_PID ---
rahmen_ref_4 = visu.create_frame_reference("AutomationLibrary2.FPL_PID")
rahmen_obj_4 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_4.set_frame_references([rahmen_ref_4])

rahmen_obj_4.set_property("Position.X", 267)
rahmen_obj_4.set_property("Position.Y", 140)
rahmen_obj_4.set_property("Position.Breite", 185)
rahmen_obj_4.set_property("Position.Höhe", 295)

rahmen_obj_4.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_PID.Name",
    "'FIC300'")

rahmen_obj_4.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_PID.Contr",
    "U300")

# --- Rahmen 6 wird hinzugefügt: VIS_TANK_B ---
rahmen_ref_5 = visu.create_frame_reference("AutomationLibrary2.VIS_TANK_B")
rahmen_obj_5 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_5.set_frame_references([rahmen_ref_5])

rahmen_obj_5.set_property("Position.X", 20)
rahmen_obj_5.set_property("Position.Y", 475)
rahmen_obj_5.set_property("Position.Breite", 105)
rahmen_obj_5.set_property("Position.Höhe", 140)

rahmen_obj_5.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_TANK_B.Level",
    "REAL")

# --- Rahmen 7 wird hinzugefügt: SBL_BIN ---
rahmen_ref_6 = visu.create_frame_reference("AutomationLibrary2.SBL_BIN")
rahmen_obj_6 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_6.set_frame_references([rahmen_ref_6])

rahmen_obj_6.set_property("Position.X", 125)
rahmen_obj_6.set_property("Position.Y", 530)
rahmen_obj_6.set_property("Position.Breite", 80)
rahmen_obj_6.set_property("Position.Höhe", 30)

rahmen_obj_6.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.Text",
    "'LS100'")

rahmen_obj_6.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.BIN",
    "L100")

# --- Rahmen 8 wird hinzugefügt: SBL_Pump ---
rahmen_ref_7 = visu.create_frame_reference("AutomationLibrary2.SBL_Pump")
rahmen_obj_7 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_7.set_frame_references([rahmen_ref_7])

rahmen_obj_7.set_property("Position.X", 322)
rahmen_obj_7.set_property("Position.Y", 502)
rahmen_obj_7.set_property("Position.Breite", 75)
rahmen_obj_7.set_property("Position.Höhe", 85)

rahmen_obj_7.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump.Text",
    "'NS200'")

rahmen_obj_7.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump.IDF",
    "N200")

# --- Rahmen 9 wird hinzugefügt: VIS_Vessel ---
rahmen_ref_8 = visu.create_frame_reference("AutomationLibrary2.VIS_Vessel")
rahmen_obj_8 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_8.set_frame_references([rahmen_ref_8])

rahmen_obj_8.set_property("Position.X", 515)
rahmen_obj_8.set_property("Position.Y", 475)
rahmen_obj_8.set_property("Position.Breite", 105)
rahmen_obj_8.set_property("Position.Höhe", 140)

rahmen_obj_8.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Vessel.AIN",
    "L200")

# --- Rahmen 10 wird hinzugefügt: SBL_Level ---
rahmen_ref_9 = visu.create_frame_reference("AutomationLibrary2.SBL_Level")
rahmen_obj_9 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_9.set_frame_references([rahmen_ref_9])

rahmen_obj_9.set_property("Position.X", 620)
rahmen_obj_9.set_property("Position.Y", 475)
rahmen_obj_9.set_property("Position.Breite", 120)
rahmen_obj_9.set_property("Position.Höhe", 140)

rahmen_obj_9.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Level.Text",
    "'LIS200'")

rahmen_obj_9.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Level.AIN",
    "L200")

# --- Start-Schaltfläche wird hinzugefügt ---
start_button = elementlist.add_element(VisualElementType.Ellipse)
start_button.set_property("Position.X", 175)
start_button.set_property("Position.Y", 20)
start_button.set_property("Position.Breite", 50)
start_button.set_property("Position.Höhe", 50)
start_button.set_property("Farben.Normalzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Normalzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Aussehen.Linienstärke", 1)
start_button.set_property("Aussehen.Füllart", "Ausgefüllt")
start_button.set_property("Aussehen.Linienart", "Durchgezogen")
start_button.set_property("Texte.Text", "Start")
start_button.set_property("Farbvariablen.Farbumschlag", "Ablauf.Start")
start_button.set_property("Eingabekonfiguration.Tasten.Variable", "Ablauf.Start")

visu.end_modify()

print("HMI erfolgreich mit mehreren Rahmen und Start-Schaltfläche im Projekt erzeugt.")
print("Hinweis: das Projekt wurde NICHT automatisch gespeichert.")
