# -*- coding: utf-8 -*-
from scriptengine import*
import os

scriptfile = os.path.dirname(__file__)
projectfile = os.path.join(scriptfile, "automatische Projektgenerierung")

if projects.primary:
    prj = projects.primary
else:
    prj = projects.open(projectfile)

apl = prj.active_application
visu = apl.create_visualobject("Visualisierung_Forderband")

visu.begin_modify()
elementlist = visu.visual_element_list

# --- Rahmen 1 wird hinzugefügt: VIS_Band ---
rahmen_ref_0 = visu.create_frame_reference("AutomationLibrary2.VIS_Band")
rahmen_obj_0 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_0.set_frame_references([rahmen_ref_0])

rahmen_obj_0.set_property("Position.X", 20)
rahmen_obj_0.set_property("Position.Y", 20)
rahmen_obj_0.set_property("Position.Breite", 280)
rahmen_obj_0.set_property("Position.Höhe", 295)

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Band.Motor",
    "N1")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Band.End1",
    "G1")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Band.End2",
    "G2")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Band.Position",
    "REAL")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Band.TxtMotor",
    "'NS1'")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Band.TxtEnd2",
    "'GS2'")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Band.TxtEnd1",
    "'GS1'")

# --- Rahmen 2 wird hinzugefügt: FPL_Motor2_Light ---
rahmen_ref_1 = visu.create_frame_reference("AutomationLibrary2.FPL_Motor2_Light")
rahmen_obj_1 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_1.set_frame_references([rahmen_ref_1])

rahmen_obj_1.set_property("Position.X", 340)
rahmen_obj_1.set_property("Position.Y", 42)
rahmen_obj_1.set_property("Position.Breite", 110)
rahmen_obj_1.set_property("Position.Höhe", 250)

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_Motor2_Light.Name",
    "'NS1'")

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_Motor2_Light.IDF",
    "N1")

# --- Start-Schaltfläche wird hinzugefügt ---
start_button = elementlist.add_element(VisualElementType.Ellipse)
start_button.set_property("Position.X", 470)
start_button.set_property("Position.Y", 20)
start_button.set_property("Position.Breite", 50)
start_button.set_property("Position.Höhe", 50)
start_button.set_property("Farben.Normalzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Normalzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Aussehen.Linienstärke", 1)
start_button.set_property("Aussehen.Füllart", "Ausgefüllt")
start_button.set_property("Aussehen.Linienart", "Durchgezogen")
start_button.set_property("Texte.Text", "Start")
start_button.set_property("Farbvariablen.Farbumschlag", "Ablauf.Start")
start_button.set_property("Eingabekonfiguration.Tasten.Variable", "Ablauf.Start")

visu.end_modify()

print("HMI erfolgreich mit mehreren Rahmen und Start-Schaltfläche im Projekt erzeugt.")
print("Hinweis: das Projekt wurde NICHT automatisch gespeichert.")
