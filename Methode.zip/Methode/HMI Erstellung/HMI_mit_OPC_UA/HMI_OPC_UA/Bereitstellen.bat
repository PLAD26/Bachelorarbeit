@echo off
cd /d "%~dp0"
node server1.js
pause