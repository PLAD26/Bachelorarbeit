# -*- coding: utf-8 -*-
from scriptengine import*
import os

scriptfile = os.path.dirname(__file__)
projectfile = os.path.join(scriptfile, "automatische Projektgenerierung")

if projects.primary:
    prj = projects.primary
else:
    prj = projects.open(projectfile)

apl = prj.active_application
visu = apl.create_visualobject("Visualisierung_Mischanlage")

visu.begin_modify()
elementlist = visu.visual_element_list

# --- Rahmen 1 wird hinzugefügt: SBL_Mixer ---
rahmen_ref_0 = visu.create_frame_reference("AutomationLibrary2.SBL_Mixer")
rahmen_obj_0 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_0.set_frame_references([rahmen_ref_0])

rahmen_obj_0.set_property("Position.X", 385)
rahmen_obj_0.set_property("Position.Y", 20)
rahmen_obj_0.set_property("Position.Breite", 55)
rahmen_obj_0.set_property("Position.Höhe", 250)

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Mixer.Text",
    "'NS3'")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Mixer.IDF",
    "N3")

# --- Rahmen 2 wird hinzugefügt: VIS_TANK_G ---
rahmen_ref_1 = visu.create_frame_reference("AutomationLibrary2.VIS_TANK_G")
rahmen_obj_1 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_1.set_frame_references([rahmen_ref_1])

rahmen_obj_1.set_property("Position.X", 20)
rahmen_obj_1.set_property("Position.Y", 310)
rahmen_obj_1.set_property("Position.Breite", 105)
rahmen_obj_1.set_property("Position.Höhe", 140)

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_TANK_G.Level",
    "REAL")

# --- Rahmen 3 wird hinzugefügt: SBL_Pump_H ---
rahmen_ref_2 = visu.create_frame_reference("AutomationLibrary2.SBL_Pump_H")
rahmen_obj_2 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_2.set_frame_references([rahmen_ref_2])

rahmen_obj_2.set_property("Position.X", 165)
rahmen_obj_2.set_property("Position.Y", 347)
rahmen_obj_2.set_property("Position.Breite", 115)
rahmen_obj_2.set_property("Position.Höhe", 65)

rahmen_obj_2.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump_H.Text",
    "'NS1'")

rahmen_obj_2.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump_H.IDF",
    "N1")

# --- Rahmen 4 wird hinzugefügt: VIS_TANK_R ---
rahmen_ref_3 = visu.create_frame_reference("AutomationLibrary2.VIS_TANK_R")
rahmen_obj_3 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_3.set_frame_references([rahmen_ref_3])

rahmen_obj_3.set_property("Position.X", 320)
rahmen_obj_3.set_property("Position.Y", 310)
rahmen_obj_3.set_property("Position.Breite", 105)
rahmen_obj_3.set_property("Position.Höhe", 140)

rahmen_obj_3.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_TANK_R.Level",
    "REAL")

# --- Rahmen 5 wird hinzugefügt: SBL_BIN ---
rahmen_ref_4 = visu.create_frame_reference("AutomationLibrary2.SBL_BIN")
rahmen_obj_4 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_4.set_frame_references([rahmen_ref_4])

rahmen_obj_4.set_property("Position.X", 425)
rahmen_obj_4.set_property("Position.Y", 310)
rahmen_obj_4.set_property("Position.Breite", 80)
rahmen_obj_4.set_property("Position.Höhe", 30)

rahmen_obj_4.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.Text",
    "'LS3'")

rahmen_obj_4.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.BIN",
    "L3")

# --- Rahmen 6 wird hinzugefügt: SBL_BIN ---
rahmen_ref_5 = visu.create_frame_reference("AutomationLibrary2.SBL_BIN")
rahmen_obj_5 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_5.set_frame_references([rahmen_ref_5])

rahmen_obj_5.set_property("Position.X", 425)
rahmen_obj_5.set_property("Position.Y", 365)
rahmen_obj_5.set_property("Position.Breite", 80)
rahmen_obj_5.set_property("Position.Höhe", 30)

rahmen_obj_5.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.Text",
    "'LS2'")

rahmen_obj_5.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.BIN",
    "L2")

# --- Rahmen 7 wird hinzugefügt: SBL_BIN ---
rahmen_ref_6 = visu.create_frame_reference("AutomationLibrary2.SBL_BIN")
rahmen_obj_6 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_6.set_frame_references([rahmen_ref_6])

rahmen_obj_6.set_property("Position.X", 425)
rahmen_obj_6.set_property("Position.Y", 420)
rahmen_obj_6.set_property("Position.Breite", 80)
rahmen_obj_6.set_property("Position.Höhe", 30)

rahmen_obj_6.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.Text",
    "'LS1'")

rahmen_obj_6.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN.BIN",
    "L1")

# --- Rahmen 8 wird hinzugefügt: SBL_Pump_H ---
rahmen_ref_7 = visu.create_frame_reference("AutomationLibrary2.SBL_Pump_H")
rahmen_obj_7 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_7.set_frame_references([rahmen_ref_7])

rahmen_obj_7.set_property("Position.X", 545)
rahmen_obj_7.set_property("Position.Y", 347)
rahmen_obj_7.set_property("Position.Breite", 115)
rahmen_obj_7.set_property("Position.Höhe", 65)

rahmen_obj_7.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump_H.Text",
    "'NS2'")

rahmen_obj_7.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump_H.IDF",
    "N2")

# --- Rahmen 9 wird hinzugefügt: VIS_TANK_B ---
rahmen_ref_8 = visu.create_frame_reference("AutomationLibrary2.VIS_TANK_B")
rahmen_obj_8 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_8.set_frame_references([rahmen_ref_8])

rahmen_obj_8.set_property("Position.X", 700)
rahmen_obj_8.set_property("Position.Y", 310)
rahmen_obj_8.set_property("Position.Breite", 105)
rahmen_obj_8.set_property("Position.Höhe", 140)

rahmen_obj_8.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_TANK_B.Level",
    "REAL")

# --- Rahmen 10 wird hinzugefügt: SBL_Valve ---
rahmen_ref_9 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_9 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_9.set_frame_references([rahmen_ref_9])

rahmen_obj_9.set_property("Position.X", 370)
rahmen_obj_9.set_property("Position.Y", 490)
rahmen_obj_9.set_property("Position.Breite", 85)
rahmen_obj_9.set_property("Position.Höhe", 60)

rahmen_obj_9.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS1'")

rahmen_obj_9.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y1")

# --- Start-Schaltfläche wird hinzugefügt ---
start_button = elementlist.add_element(VisualElementType.Ellipse)
start_button.set_property("Position.X", 20)
start_button.set_property("Position.Y", 20)
start_button.set_property("Position.Breite", 50)
start_button.set_property("Position.Höhe", 50)
start_button.set_property("Farben.Normalzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Normalzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Aussehen.Linienstärke", 1)
start_button.set_property("Aussehen.Füllart", "Ausgefüllt")
start_button.set_property("Aussehen.Linienart", "Durchgezogen")
start_button.set_property("Texte.Text", "Start")
start_button.set_property("Farbvariablen.Farbumschlag", "Ablauf.Start")
start_button.set_property("Eingabekonfiguration.Tasten.Variable", "Ablauf.Start")

visu.end_modify()

print("HMI erfolgreich mit mehreren Rahmen und Start-Schaltfläche im Projekt erzeugt.")
print("Hinweis: das Projekt wurde NICHT automatisch gespeichert.")
