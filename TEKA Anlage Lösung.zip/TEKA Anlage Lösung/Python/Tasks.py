# -*- coding: utf-8 -*-
# Erzeugt mit: task_skript_generator.py
"""
Erstellt in einem bestehenden CODESYS-Projekt eine Taskkonfiguration.
Automatisch generiert aus: Tasks LIste.xlsx

Tasks:
  - "MainTask": Prioritaet 1, Cyclic, T#20ms, Programme: PLC_PRG, Ablauf, LSH3104, LIS3106, LSH3204, LIS3301, TIC3107, TIC3302, YS3101, YS3102, NS3103, YS3105, ES3108, YS3201, NS3202, NS3203, YS3205, ES3303, NC3304, YS3305, kein Watchdog

Ausfuehrung: Tools -> Scripting -> Skriptdatei ausfuehren...
"""
from __future__ import print_function  # Kompatibilität: print() als Funktion

# Konfiguration der Tasks:
# (Name, Prioritaet, Typ (KindOfTask), Intervall/Ereignis, [Programme], Watchdog)
# Watchdog = None (nicht aktiv) oder (Zeit in ms, Empfindlichkeit)
TASKS = [
    ('MainTask', '1', 'Cyclic', 'T#20ms', ['PLC_PRG', 'Ablauf', 'LSH3104', 'LIS3106', 'LSH3204', 'LIS3301', 'TIC3107', 'TIC3302', 'YS3101', 'YS3102', 'NS3103', 'YS3105', 'ES3108', 'YS3201', 'NS3202', 'NS3203', 'YS3205', 'ES3303', 'NC3304', 'YS3305'], None),
]


def zeige_projektbaum(projekt):
    """Gibt alle Objekte des Projektbaums zur Diagnose aus (rekursiv)."""
    print("Projekt: " + str(projekt))
    for objekt in projekt.get_children(True):  # True = alle Unterobjekte durchsuchen
        try:
            print("  - " + objekt.get_name())
        except Exception:
            print("  - (Name nicht lesbar)")


def finde_application(projekt):
    """Sucht die Application rekursiv ueber den Objekttyp (nicht ueber feste Namen)."""
    # 1) Rekursive Suche ueber die Typpruefung is_application
    for objekt in projekt.get_children(True):  # True = gesamten Baum durchsuchen
        try:
            if objekt.is_application:  # Typpruefung statt Namensvergleich
                return objekt
        except Exception:
            pass  # Objekt hat die Eigenschaft nicht -> naechstes Objekt
    # 2) Fallback: nach dem Namen "Application" suchen
    for objekt in projekt.get_children(True):
        try:
            if objekt.get_name() == "Application":
                return objekt
        except Exception:
            pass
    return None


def finde_taskkonfig(application):
    """Sucht eine vorhandene Taskkonfiguration ueber den Objekttyp (Name ist sprachabhaengig)."""
    for objekt in application.get_children(True):  # gesamten Baum unter der Application durchsuchen
        try:
            if objekt.is_task_configuration:  # Typpruefung statt Namensvergleich
                return objekt
        except Exception:
            pass  # Objekt hat die Eigenschaft nicht -> naechstes Objekt
    return None


def finde_kind(eltern, name):
    """Sucht ein direktes Kind-Objekt per Name."""
    for kind in eltern.get_children(False):  # nur direkte Kind-Objekte durchsuchen
        if kind.get_name() == name:
            return kind
    return None


def finde_kind_of_task(typ):
    """Sucht den Aufzaehlungswert KindOfTask.<typ> ueber verschiedene Zugriffswege."""
    werte = []  # werte = gefundene Kandidaten für den Aufzählungswert
    # 1) Globaler Name in der Skriptumgebung
    try:
        werte.append(getattr(KindOfTask, typ))  # noqa: F821
    except Exception:
        pass
    # 2) Ueber das Modul scriptengine
    try:
        import scriptengine
        werte.append(getattr(scriptengine.KindOfTask, typ))
    except Exception:
        pass
    # 3) Ueber .NET-Reflection in den geladenen Assemblies
    try:
        import clr
        import System
        for asm in System.AppDomain.CurrentDomain.GetAssemblies():
            for t in asm.GetTypes():
                if t.Name == "KindOfTask":
                    werte.append(System.Enum.Parse(t, typ))
                    raise StopIteration  # Suche beenden, sobald der Typ gefunden ist
    except StopIteration:  # normales Ende der Suche
        pass
    except Exception as fehler:
        print("Reflection fuer KindOfTask fehlgeschlagen: " + str(fehler))
    return werte


def setze_mit_varianten(objekt, attribut, varianten):
    """Setzt ein Attribut und probiert dabei mehrere Wertvarianten (String/Zahl/IEC-Zeit)."""
    for wert in varianten:  # Varianten nacheinander versuchen
        try:
            setattr(objekt, attribut, wert)  # Attribut mit der Variante setzen
            print("Gesetzt: " + attribut + " = " + repr(wert))
            return True  # Erfolg -> keine weitere Variante nötig
        except Exception as fehler:
            print(attribut + " mit " + repr(wert) + " fehlgeschlagen: " + str(fehler))
    return False  # keine Variante hat funktioniert


def setze_watchdog(task, zeit_ms, empfindlichkeit):
    """Aktiviert den Watchdog einer Task und setzt Zeit und Empfindlichkeit."""
    if not hasattr(task, "watchdog"):  # Eigenschaft muss vorhanden sein
        raise RuntimeError("Task hat keine Eigenschaft 'watchdog'.")
    wd = task.watchdog  # wd = Watchdog-Objekt der Task
    namen = [n for n in ("enabled", "time", "sensitivity", "unit")  # vorhandene Eigenschaften für die Diagnose ermitteln
             if hasattr(wd, n)]
    print("watchdog -> hasattr: " + ", ".join(namen))

    # Zeit, Empfindlichkeit und Aktivierung setzen (mit mehreren Wertvarianten)
    ok_zeit = setze_mit_varianten(
        wd, "time", [str(zeit_ms), "T#" + str(zeit_ms) + "ms", zeit_ms])
    ok_emp = setze_mit_varianten(
        wd, "sensitivity", [str(empfindlichkeit), empfindlichkeit])
    ok_akt = setze_mit_varianten(wd, "enabled", [True])
    if not (ok_zeit and ok_emp and ok_akt):
        raise RuntimeError("Watchdog konnte nicht vollstaendig gesetzt werden.")
    print("Watchdog: enabled=" + str(wd.enabled) + ", time=" + str(wd.time) +  # Kontrollausgabe der gesetzten Werte
          ", sensitivity=" + str(wd.sensitivity))


def erstelle_task(application, taskkonfig, name, prioritaet, typ, intervall,
                  programme, watchdog):
    """Legt eine Task an, setzt Typ/Intervall/Watchdog und fuegt die Programmaufrufe hinzu."""
    print("--- Task '" + name + "' ---")

    # Task anlegen, falls nicht vorhanden
    task = finde_kind(taskkonfig, name)
    if task is None:
        task = taskkonfig.create_task(name)  # neue Task anlegen
        if task is None:  # ggf. erneut suchen
            task = finde_kind(taskkonfig, name)
    if task is None:
        raise RuntimeError("Task '" + name + "' nicht gefunden.")
    print("Task vorhanden: " + task.get_name())

    # Typ der Task (zuerst, da er die uebrigen Eigenschaften beeinflusst)
    gesetzt = False  # Merker: Typ erfolgreich gesetzt
    for wert in finde_kind_of_task(typ):  # alle Kandidatenwerte probieren
        try:
            task.kind_of_task = wert  # Typ der Task setzen
            print("Gesetzt: kind_of_task = " + str(wert))
            gesetzt = True
            break  # ersten funktionierenden Wert verwenden
        except Exception as fehler:
            print("kind_of_task mit " + str(wert) + " fehlgeschlagen: " + str(fehler))
    if not gesetzt:
        print("Warnung: kind_of_task = " + typ + " konnte nicht gesetzt werden.")

    # Prioritaet
    task.priority = prioritaet
    print("Gesetzt: priority = " + prioritaet)

    # Intervall (zyklisch) bzw. Ereignis (Ereignis/Externes)
    if intervall:
        if typ == "Cyclic":
            task.interval = intervall  # IEC-Zeit, z. B. T#20ms
            print("Gesetzt: interval = " + intervall)
        else:
            ok = False  # Merker: Ereignis erfolgreich gesetzt
            for attr in ("event", "interval"):  # mögliche Eigenschaftsnamen für das Ereignis
                if hasattr(task, attr):
                    ok = setze_mit_varianten(task, attr, [intervall])
                    if ok:
                        break
            if not ok:
                print("Warnung: Ereignis '" + intervall + "' konnte nicht gesetzt werden.")

    # Watchdog (nur wenn gewuenscht)
    if watchdog is not None:
        setze_watchdog(task, watchdog[0], watchdog[1])

    # Programmaufrufe hinzufuegen (Eigenschaft "pous" der Task)
    if programme and not hasattr(task, "pous"):
        raise RuntimeError("Task hat keine Eigenschaft 'pous'.")
    for programm in programme:
        # Pruefen, ob das Programm im Projekt existiert (nur Warnung)
        if finde_kind(application, programm) is None:
            print("Warnung: Programm '" + programm + "' wurde unter der Application "
                  "nicht gefunden. Der Aufruf kann fehlschlagen.")
        task.pous.add(programm)  # Programmaufruf zur Task hinzufügen
        print("Programmaufruf '" + programm + "' hinzugefuegt.")


# Hauptteil: wird beim Ausführen des Skripts in CODESYS abgearbeitet
projekt = projects.primary  # aktuell geöffnetes Projekt (Objekt 'projects' stellt CODESYS bereit)
if projekt is None:
    raise RuntimeError("Es ist kein Projekt geoeffnet.")

application = finde_application(projekt)  # Application im Projektbaum suchen
if application is None:
    zeige_projektbaum(projekt)  # Diagnose: Projektbaum ausgeben, damit man die Namen sieht
    raise RuntimeError("Application nicht gefunden.")
print("Application gefunden: " + application.get_name())

# Taskkonfiguration anlegen, falls nicht vorhanden
taskkonfig = finde_taskkonfig(application)  # vorhandene Taskkonfiguration ueber den Typ suchen
if taskkonfig is None:
    print("Keine Taskkonfiguration gefunden, lege eine neue an.")
    application.create_task_configuration()  # Taskkonfiguration neu anlegen
    taskkonfig = finde_taskkonfig(application)
if taskkonfig is None:
    raise RuntimeError("Taskkonfiguration konnte nicht angelegt werden.")
print("Taskkonfiguration vorhanden: " + taskkonfig.get_name())

# Alle Tasks erstellen
for name, prio, typ, intervall, programme, watchdog in TASKS:  # Daten aus der Liste TASKS entpacken
    erstelle_task(application, taskkonfig, name, prio, typ, intervall,
                  programme, watchdog)

projekt.save()  # Änderungen speichern
print("Projekt gespeichert. Fertig.")
