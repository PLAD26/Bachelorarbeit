# -*- coding: utf-8 -*-
"""
Programm : steuerungskonfig_generator.py   (AUTOMATISCH ERZEUGT, nicht von Hand ändern)
Zweck    : Fügt in das geöffnete CODESYS-Projekt (V3.5 SP21 Patch 2) die
           Steuerungskonfiguration ein. Alle Daten stammen aus der JSON-Datei.
Start    : Zuerst das Projekt in CODESYS öffnen, dann
           Tools -> Scripting -> Skriptdatei ausführen
Hinweis  : Das Projekt wird NICHT automatisch gespeichert (danach Strg+S).
Hinweis  : Läuft im Scripting Engine (IronPython 2.7), nicht in normalem Python.
"""
from __future__ import print_function
import os
import re

# ======================================================================
# KONFIGURATION (aus JSON-Datei und Ordner "GSD")
# ======================================================================
# Gerätebeschreibungen (GSDML/XML) aus dem Ordner "GSD"
GSD_DATEIEN = [
    u"C:\\Users\\alipe\\Downloads\\Github\\TEKA Anlage L\u00f6sung\\Steuerungskonfiguration Erstellung\\GSDML\\GSDML-V2.25-Siemens-ET200S-20191007.xml",
]
GSD_NEU_INSTALLIEREN = True    # True = GSDML immer installieren

# Steuerung: (Name im Projekt, Suchtext im Geräte-Repository)
STEUERUNG = (u"Soft_SPS", u"CODESYS Control Win V3 x64")
STEUERUNG_VERSION = u"3.5.21.20"

# Geräte: (Name im Projekt, Suchtext im Geräte-Repository, Name des Elterngeräts)
GERAETE = [
    (u"Ethernet1", u"Ethernet", u"Soft_SPS"),
    (u"Controller1", u"PN_Controller", u"Ethernet1"),
    (u"RIO_ET200S", u"IM151-3 PN V1.0", u"Controller1"),
]

# Module: (Name im Projekt, Modulname laut GSDML, Name des Elterngeräts, Suchtext des Elterngeräts)
MODULE = [
    (u"PowerSupply", u"PM-E DC24V", u"RIO_ET200S", u"IM151-3 PN V1.0"),
    (u"Digital_Inputs", u"2DI DC24V HF", u"RIO_ET200S", u"IM151-3 PN V1.0"),
    (u"Digital_Outputs_1", u"4DO DC24V/2A ST", u"RIO_ET200S", u"IM151-3 PN V1.0"),
    (u"Digital_Outputs_2", u"4DO DC24V/2A ST", u"RIO_ET200S", u"IM151-3 PN V1.0"),
    (u"Digital_Outputs_3", u"4DO DC24V/2A ST", u"RIO_ET200S", u"IM151-3 PN V1.0"),
    (u"Analog_Inputs", u"4AI I 2WIRE ST", u"RIO_ET200S", u"IM151-3 PN V1.0"),
    (u"Analog_Outputs", u"2AO I ST", u"RIO_ET200S", u"IM151-3 PN V1.0"),
]

# ST-Programm: Sensoren (Variable des Bausteins, reale Adresse) -> Variable := Adresse
SENSOREN = [
    (u"L3104.IN", u"%IX0.0"),
    (u"L3204.IN", u"%IX0.1"),
    (u"L3106.X_W", u"%IW1"),
    (u"T3107.X_W", u"%IW3"),
    (u"L3301.X_W", u"%IW5"),
    (u"T3302.X_W", u"%IW7"),
]
# Aktoren (Variable des Bausteins, reale Adresse) -> Adresse := Variable
AKTOREN = [
    (u"Y3101.OUT", u"%QX0.0"),
    (u"Y3102.OUT", u"%QX0.1"),
    (u"N3103.OUT", u"%QX0.2"),
    (u"Y3105.OUT", u"%QX0.3"),
    (u"E3108.OUT", u"%QX1.0"),
    (u"Y3201.OUT", u"%QX1.1"),
    (u"N3202.OUT", u"%QX1.2"),
    (u"N3203.OUT", u"%QX1.3"),
    (u"Y3205.OUT", u"%QX2.0"),
    (u"E3303.OUT", u"%QX2.1"),
    (u"Y3305.OUT", u"%QX2.2"),
    (u"N3304.Y_W", u"%QW3"),
]
PROGRAMM_NAME = u"PLC_PRG"
SCHALTER_NAME = u"Anlage"          # True = reale E/A, False = Simulation
SIMULATION_AUFRUF = u"Simulation();"

# Von Geräten automatisch angelegte Untermodule: Gerätename -> Menge normalisierter Namen
AUTO_MODULE = {}


# ======================================================================
# GERÄTE-REPOSITORY
# ======================================================================
def _norm(text):
    """Vergleichsform: ohne Leerzeichen, '_' und '-', kleingeschrieben."""
    return re.sub(r"[\s_\-]+", "", str(text)).lower()


def _feld(objekt, *namen):
    """Liest das erste vorhandene Attribut (Schreibweise je nach Version verschieden)."""
    for n in namen:
        wert = getattr(objekt, n, None)
        if wert is not None:
            return wert
    return None


def alle_geraete():
    return list(device_repository.get_all_devices())


def geraet_name(g):
    return str(g.device_info.name)


def versions_schluessel(g):
    """Wandelt '3.5.21.20' in (3, 5, 21, 20) um, damit Versionen sortierbar sind."""
    text = str(_feld(g.device_id, "version", "Version"))
    try:
        return tuple(int(t) for t in text.split("."))
    except ValueError:
        return (0,)


def geraet_suchen(suchtext, version=""):
    """Sucht ein Gerät im Repository (bei mehreren Versionen die vorgegebene oder die neueste)."""
    ziel = _norm(suchtext)
    treffer = [g for g in alle_geraete() if ziel in _norm(geraet_name(g))]
    if not treffer:
        raise Exception("Gerät nicht im Repository gefunden: " + suchtext)
    genau = [g for g in treffer if _norm(geraet_name(g)) == ziel]
    kandidaten = genau if genau else treffer
    if version:
        passend = [g for g in kandidaten
                   if str(_feld(g.device_id, "version", "Version")) == version]
        if passend:
            kandidaten = passend
        else:
            print("  Hinweis: Version %s für '%s' nicht gefunden, nehme neueste" % (version, suchtext))
    auswahl = max(kandidaten, key=versions_schluessel)
    print("  Gewählt: %s | %s" % (geraet_name(auswahl), auswahl.device_id))
    return auswahl


def _gsd_bereits_installiert(pfad):
    """Prüft anhand des Dateinamens, ob die GSDML schon im Repository ist."""
    stamm = os.path.splitext(os.path.basename(pfad))[0]
    kern = re.sub(r"^GSDML-V[\d.]+-", "", stamm)     # 'GSDML-V2.34-Buerkert-...' -> 'Buerkert-...'
    return any(kern in str(g.device_id) for g in alle_geraete())


def gsd_installieren():
    """Installiert die GSDML-Dateien im Geräte-Repository (wie Tools -> Geräte-Repository)."""
    from System import Guid
    wandler = Guid("{C633F245-876F-45E8-AAB4-3FBD994C08B8}")   # Konverter für Fremdformate
    try:
        quellen = list(device_repository.sources)
    except Exception:
        quellen = [device_repository.sources[0]]
    for pfad in GSD_DATEIEN:
        if not os.path.exists(pfad):
            print("GSDML-Datei nicht gefunden:", pfad)
            continue
        if not GSD_NEU_INSTALLIEREN and _gsd_bereits_installiert(pfad):
            print("GSDML bereits installiert:", os.path.basename(pfad))
            continue
        letzter_fehler = None
        for quelle in quellen:
            try:
                if device_repository.import_device(pfad, quelle, wandler) is not None:
                    print("GSDML installiert:", os.path.basename(pfad))
                    break
            except Exception as fehler:
                letzter_fehler = fehler
        else:
            print("GSDML-Installation fehlgeschlagen (evtl. keine GSDML):",
                  os.path.basename(pfad), "|", letzter_fehler)


# ======================================================================
# STEUERUNGSKONFIGURATION
# ======================================================================
def objekt_finden(projekt, name):
    treffer = projekt.find(name, True)
    if not treffer:
        raise Exception("Objekt nicht gefunden: " + name)
    return treffer[0]


def kinder_namen(objekt):
    """Normalisierte Namen aller Unterobjekte eines Geräts (für die Erkennung automatischer Module)."""
    namen = set()
    try:
        kinder = objekt.get_children(True)
    except Exception:
        return namen
    for k in kinder:
        try:
            namen.add(_norm(k.get_name()))
        except Exception:
            pass
    return namen


def geraet_anhaengen(eltern, name, suchtext, version=""):
    """Hängt ein Gerät an das Elternobjekt an (entspricht 'Gerät anhängen')."""
    did = geraet_suchen(suchtext, version).device_id
    return eltern.add(name, _feld(did, "type", "Type"), _feld(did, "id", "Id"),
                      _feld(did, "version", "Version"))


def gsd_module_lesen(pfad, dap_id):
    """Liest (ModuleItem-ID, Name) der für den Zugangspunkt zulässigen Module aus der GSDML.
    Gibt None zurück, wenn der Zugangspunkt in dieser Datei nicht vorkommt."""
    import clr
    clr.AddReference("System.Xml")
    from System.Xml import XmlDocument
    dok = XmlDocument()
    dok.Load(pfad)
    dap = dok.SelectSingleNode("//*[local-name()='DeviceAccessPointItem'][@ID='%s']" % dap_id)
    if dap is None:
        return None
    texte = {}
    for t in dok.SelectNodes("//*[local-name()='Text']"):
        texte[t.GetAttribute("TextId")] = t.GetAttribute("Value")
    erlaubt = set()
    for r in dap.SelectNodes(".//*[local-name()='ModuleItemRef']"):
        erlaubt.add(r.GetAttribute("ModuleItemTarget"))
    ergebnis = []
    for m in dok.SelectNodes("//*[local-name()='ModuleItem']"):
        modul_id = m.GetAttribute("ID")
        if erlaubt and modul_id not in erlaubt:
            continue
        name_knoten = m.SelectSingleNode(".//*[local-name()='Name']")
        tid = name_knoten.GetAttribute("TextId") if name_knoten is not None else ""
        ergebnis.append((modul_id, texte.get(tid, tid)))
    return ergebnis


def modul_ist_automatisch(projekt, name, modul_name, eltern_name):
    """True, wenn das Gerät dieses Modul schon selbst angelegt hat (dann wird es ignoriert)."""
    vorhanden = AUTO_MODULE.get(eltern_name, set())
    if _norm(name) in vorhanden or _norm(modul_name) in vorhanden:
        return True
    return bool(projekt.find(name, True))      # Objekt mit diesem Namen existiert schon


def modul_anhaengen(eltern, name, modul_name, geraet_suchtext):
    """Hängt ein Modul an ein Gerät an; die zugehörige GSDML wird in allen XML gesucht."""
    did = geraet_suchen(geraet_suchtext).device_id
    kennung = _feld(did, "id", "Id")
    dap_id = str(kennung).rsplit(" - ", 1)[-1]                 # z. B. 'DIM 20'
    for pfad in GSD_DATEIEN:
        if not os.path.exists(pfad):
            continue
        module = gsd_module_lesen(pfad, dap_id)
        if module is None:
            continue
        treffer = [i for i, n in module if _norm(n) == _norm(modul_name)]
        if treffer:
            return eltern.add(name, _feld(did, "type", "Type"), kennung,
                              _feld(did, "version", "Version"), treffer[0])
    raise Exception("Modul nicht in den GSDML-Dateien gefunden: " + modul_name)


# ======================================================================
# ST-PROGRAMM PLC_PRG
# ======================================================================
def st_deklaration_bauen():
    return "PROGRAM %s\nVAR\n    %s : BOOL;\nEND_VAR\n" % (PROGRAMM_NAME, SCHALTER_NAME)


def st_code_bauen():
    """Erzeugt den ST-Code: reale Eingänge -> Bausteine, Bausteine -> reale Ausgänge."""
    teile = []
    if SENSOREN:
        zeilen = ["IF %s THEN" % SCHALTER_NAME]
        zeilen += ["    %s := %s;" % (variable, adresse) for variable, adresse in SENSOREN]
        zeilen += ["ELSE", "    " + SIMULATION_AUFRUF, "END_IF"]
        teile.append("\n".join(zeilen))
    if AKTOREN:
        zeilen = ["IF %s THEN" % SCHALTER_NAME]
        zeilen += ["    %s := %s;" % (adresse, variable) for variable, adresse in AKTOREN]
        zeilen += ["END_IF"]
        teile.append("\n".join(zeilen))
    return "\n\n".join(teile) + "\n"


def anwendung_finden(projekt):
    """Sucht die Application unterhalb der Steuerung."""
    sps = objekt_finden(projekt, STEUERUNG[0])
    kinder = list(sps.get_children(True))
    for o in kinder:
        if getattr(o, "is_application", False):
            return o
    for o in kinder:
        if o.get_name() == "Application":
            return o
    raise Exception("Application unterhalb von '%s' nicht gefunden." % STEUERUNG[0])


def programm_erstellen(projekt):
    """Legt das ST-Programm an (bzw. überschreibt ein vorhandenes gleichen Namens)."""
    vorhanden = projekt.find(PROGRAMM_NAME, True)
    if vorhanden:
        pou = vorhanden[0]
        print("  Programm existiert bereits, Inhalt wird ersetzt:", PROGRAMM_NAME)
    else:
        pou = anwendung_finden(projekt).create_pou(PROGRAMM_NAME, PouType.Program,
                                                   ImplementationLanguages.st)
    pou.textual_declaration.replace(st_deklaration_bauen())
    pou.textual_implementation.replace(st_code_bauen())


# ======================================================================
# HAUPTPROGRAMM
# ======================================================================
def objekt_holen_oder_anlegen(projekt, name, suchtext, eltern_name, version=""):
    """Nimmt ein schon vorhandenes Objekt oder hängt das Gerät neu an."""
    vorhanden = projekt.find(name, True)
    if vorhanden:
        print("  Bereits vorhanden, wird verwendet:", name)
        return vorhanden[0]
    neu = geraet_anhaengen(objekt_finden(projekt, eltern_name) if eltern_name else projekt,
                           name, suchtext, version)
    return neu if neu is not None else objekt_finden(projekt, name)


def erstellen():
    # 1) Das aktuell geöffnete Projekt verwenden
    projekt = projects.primary
    if projekt is None:
        raise Exception("Kein CODESYS-Projekt geöffnet. Bitte zuerst ein Projekt öffnen.")
    try:
        print("Projekt:", projekt.path)
    except Exception:
        pass

    # 2) Gerätebeschreibungen installieren
    gsd_installieren()

    # 3) Steuerung: vorhandene SPS verwenden, sonst neu hinzufügen
    print("Steuerung:", STEUERUNG[0])
    try:
        objekt_holen_oder_anlegen(projekt, STEUERUNG[0], STEUERUNG[1], None, STEUERUNG_VERSION)
    except Exception as fehler:
        print("  FEHLER bei", STEUERUNG[0], ":", fehler)

    # 4) Steuerungskonfiguration: Geräte anhängen und deren automatische Module merken
    for name, suchtext, eltern_name in GERAETE:
        print("Füge hinzu:", name)
        try:
            neu = objekt_holen_oder_anlegen(projekt, name, suchtext, eltern_name)
            AUTO_MODULE[name] = kinder_namen(neu)
            if AUTO_MODULE[name]:
                print("  Vorhandene Untermodule:", ", ".join(sorted(AUTO_MODULE[name])))
        except Exception as fehler:
            print("  FEHLER bei", name, ":", fehler)

    #    Module aus der JSON-Datei; bereits vorhandene/automatische werden ignoriert
    for name, modul_name, eltern_name, geraet_suchtext in MODULE:
        try:
            if modul_ist_automatisch(projekt, name, modul_name, eltern_name):
                print("Modul wird ignoriert (existiert bereits):", name)
                continue
            print("Füge Modul hinzu:", name)
            modul_anhaengen(objekt_finden(projekt, eltern_name), name, modul_name, geraet_suchtext)
        except Exception as fehler:
            print("  FEHLER bei Modul", name, ":", fehler)

    # 5) ST-Programm PLC_PRG: reale E/A <-> Bausteine
    if SENSOREN or AKTOREN:
        print("Erzeuge ST-Programm:", PROGRAMM_NAME)
        try:
            programm_erstellen(projekt)
            print("  %d Sensor-Zuweisung(en), %d Aktor-Zuweisung(en)" % (len(SENSOREN), len(AKTOREN)))
        except Exception as fehler:
            print("  FEHLER bei", PROGRAMM_NAME, ":", fehler)
    else:
        print("Keine Sensoren/Aktoren in 'addresses' - PLC_PRG wird nicht erzeugt.")

    print("Fertig. Das Projekt wurde nicht gespeichert - bitte mit Strg+S speichern.")

erstellen()
