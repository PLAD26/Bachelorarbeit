# -*- coding: utf-8 -*-
from scriptengine import*
import os

scriptfile = os.path.dirname(__file__)
projectfile = os.path.join(scriptfile, "automatische Projektgenerierung")

if projects.primary:
    prj = projects.primary
else:
    prj = projects.open(projectfile)

apl = prj.active_application
visu = apl.create_visualobject("Visualisierung_TEKA")

visu.begin_modify()
elementlist = visu.visual_element_list

# --- Rahmen 1 wird hinzugefügt: SBL_Valve ---
rahmen_ref_0 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_0 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_0.set_frame_references([rahmen_ref_0])

rahmen_obj_0.set_property("Position.X", 20)
rahmen_obj_0.set_property("Position.Y", 20)
rahmen_obj_0.set_property("Position.Breite", 85)
rahmen_obj_0.set_property("Position.Höhe", 60)

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS3101'")

rahmen_obj_0.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y3101")

# --- Rahmen 2 wird hinzugefügt: SBL_Valve ---
rahmen_ref_1 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_1 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_1.set_frame_references([rahmen_ref_1])

rahmen_obj_1.set_property("Position.X", 350)
rahmen_obj_1.set_property("Position.Y", 20)
rahmen_obj_1.set_property("Position.Breite", 85)
rahmen_obj_1.set_property("Position.Höhe", 60)

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS3105'")

rahmen_obj_1.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y3105")

# --- Rahmen 3 wird hinzugefügt: SBL_BIN_L ---
rahmen_ref_2 = visu.create_frame_reference("AutomationLibrary2.SBL_BIN_L")
rahmen_obj_2 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_2.set_frame_references([rahmen_ref_2])

rahmen_obj_2.set_property("Position.X", 22)
rahmen_obj_2.set_property("Position.Y", 252)
rahmen_obj_2.set_property("Position.Breite", 80)
rahmen_obj_2.set_property("Position.Höhe", 30)

rahmen_obj_2.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN_L.Text",
    "'LSH3104'")

rahmen_obj_2.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN_L.BIN",
    "L3104")

# --- Rahmen 4 wird hinzugefügt: VIS_TANK_B ---
rahmen_ref_3 = visu.create_frame_reference("AutomationLibrary2.VIS_TANK_B")
rahmen_obj_3 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_3.set_frame_references([rahmen_ref_3])

rahmen_obj_3.set_property("Position.X", 150)
rahmen_obj_3.set_property("Position.Y", 197)
rahmen_obj_3.set_property("Position.Breite", 105)
rahmen_obj_3.set_property("Position.Höhe", 140)

rahmen_obj_3.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_TANK_B.Level",
    "REAL")

# --- Rahmen 5 wird hinzugefügt: FPL_PID ---
rahmen_ref_4 = visu.create_frame_reference("AutomationLibrary2.FPL_PID")
rahmen_obj_4 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_4.set_frame_references([rahmen_ref_4])

rahmen_obj_4.set_property("Position.X", 300)
rahmen_obj_4.set_property("Position.Y", 120)
rahmen_obj_4.set_property("Position.Breite", 185)
rahmen_obj_4.set_property("Position.Höhe", 295)

rahmen_obj_4.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_PID.Name",
    "'TIC3107'")

rahmen_obj_4.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_PID.Contr",
    "U3107")

# --- Rahmen 6 wird hinzugefügt: VIS_Vessel ---
rahmen_ref_5 = visu.create_frame_reference("AutomationLibrary2.VIS_Vessel")
rahmen_obj_5 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_5.set_frame_references([rahmen_ref_5])

rahmen_obj_5.set_property("Position.X", 525)
rahmen_obj_5.set_property("Position.Y", 197)
rahmen_obj_5.set_property("Position.Breite", 105)
rahmen_obj_5.set_property("Position.Höhe", 140)

rahmen_obj_5.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Vessel.AIN",
    "L3106")

# --- Rahmen 7 wird hinzugefügt: SBL_Level ---
rahmen_ref_6 = visu.create_frame_reference("AutomationLibrary2.SBL_Level")
rahmen_obj_6 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_6.set_frame_references([rahmen_ref_6])

rahmen_obj_6.set_property("Position.X", 702)
rahmen_obj_6.set_property("Position.Y", 197)
rahmen_obj_6.set_property("Position.Breite", 120)
rahmen_obj_6.set_property("Position.Höhe", 140)

rahmen_obj_6.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Level.Text",
    "'LIS3106'")

rahmen_obj_6.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Level.AIN",
    "L3106")

# --- Rahmen 8 wird hinzugefügt: SBL_Valve ---
rahmen_ref_7 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_7 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_7.set_frame_references([rahmen_ref_7])

rahmen_obj_7.set_property("Position.X", 160)
rahmen_obj_7.set_property("Position.Y", 455)
rahmen_obj_7.set_property("Position.Breite", 85)
rahmen_obj_7.set_property("Position.Höhe", 60)

rahmen_obj_7.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS3102'")

rahmen_obj_7.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y3102")

# --- Rahmen 9 wird hinzugefügt: SBL_Valve ---
rahmen_ref_8 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_8 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_8.set_frame_references([rahmen_ref_8])

rahmen_obj_8.set_property("Position.X", 535)
rahmen_obj_8.set_property("Position.Y", 455)
rahmen_obj_8.set_property("Position.Breite", 85)
rahmen_obj_8.set_property("Position.Höhe", 60)

rahmen_obj_8.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS3201'")

rahmen_obj_8.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y3201")

# --- Rahmen 10 wird hinzugefügt: SBL_Pump_H ---
rahmen_ref_9 = visu.create_frame_reference("AutomationLibrary2.SBL_Pump_H")
rahmen_obj_9 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_9.set_frame_references([rahmen_ref_9])

rahmen_obj_9.set_property("Position.X", 145)
rahmen_obj_9.set_property("Position.Y", 555)
rahmen_obj_9.set_property("Position.Breite", 115)
rahmen_obj_9.set_property("Position.Höhe", 65)

rahmen_obj_9.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump_H.Text",
    "'NS3103'")

rahmen_obj_9.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Pump_H.IDF",
    "N3103")

# --- Rahmen 11 wird hinzugefügt: SBL_BIN_L ---
rahmen_ref_10 = visu.create_frame_reference("AutomationLibrary2.SBL_BIN_L")
rahmen_obj_10 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_10.set_frame_references([rahmen_ref_10])

rahmen_obj_10.set_property("Position.X", 352)
rahmen_obj_10.set_property("Position.Y", 572)
rahmen_obj_10.set_property("Position.Breite", 80)
rahmen_obj_10.set_property("Position.Höhe", 30)

rahmen_obj_10.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN_L.Text",
    "'LSH3204'")

rahmen_obj_10.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_BIN_L.BIN",
    "L3204")

# --- Rahmen 12 wird hinzugefügt: SBL_Valve ---
rahmen_ref_11 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_11 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_11.set_frame_references([rahmen_ref_11])

rahmen_obj_11.set_property("Position.X", 535)
rahmen_obj_11.set_property("Position.Y", 557)
rahmen_obj_11.set_property("Position.Breite", 85)
rahmen_obj_11.set_property("Position.Höhe", 60)

rahmen_obj_11.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS3205'")

rahmen_obj_11.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y3205")

# --- Rahmen 13 wird hinzugefügt: SBL_Level ---
rahmen_ref_12 = visu.create_frame_reference("AutomationLibrary2.SBL_Level")
rahmen_obj_12 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_12.set_frame_references([rahmen_ref_12])

rahmen_obj_12.set_property("Position.X", 332)
rahmen_obj_12.set_property("Position.Y", 737)
rahmen_obj_12.set_property("Position.Breite", 120)
rahmen_obj_12.set_property("Position.Höhe", 140)

rahmen_obj_12.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Level.Text",
    "'LIS3301'")

rahmen_obj_12.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Level.AIN",
    "L3301")

# --- Rahmen 14 wird hinzugefügt: VIS_Vessel ---
rahmen_ref_13 = visu.create_frame_reference("AutomationLibrary2.VIS_Vessel")
rahmen_obj_13 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_13.set_frame_references([rahmen_ref_13])

rahmen_obj_13.set_property("Position.X", 525)
rahmen_obj_13.set_property("Position.Y", 737)
rahmen_obj_13.set_property("Position.Breite", 105)
rahmen_obj_13.set_property("Position.Höhe", 140)

rahmen_obj_13.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.VIS_Vessel.AIN",
    "L3301")

# --- Rahmen 15 wird hinzugefügt: FPL_PID ---
rahmen_ref_14 = visu.create_frame_reference("AutomationLibrary2.FPL_PID")
rahmen_obj_14 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_14.set_frame_references([rahmen_ref_14])

rahmen_obj_14.set_property("Position.X", 670)
rahmen_obj_14.set_property("Position.Y", 660)
rahmen_obj_14.set_property("Position.Breite", 185)
rahmen_obj_14.set_property("Position.Höhe", 295)

rahmen_obj_14.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_PID.Name",
    "'TIC3302'")

rahmen_obj_14.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.FPL_PID.Contr",
    "U3302")

# --- Rahmen 16 wird hinzugefügt: SBL_ControlValve ---
rahmen_ref_15 = visu.create_frame_reference("AutomationLibrary2.SBL_ControlValve")
rahmen_obj_15 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_15.set_frame_references([rahmen_ref_15])

rahmen_obj_15.set_property("Position.X", 895)
rahmen_obj_15.set_property("Position.Y", 767)
rahmen_obj_15.set_property("Position.Breite", 100)
rahmen_obj_15.set_property("Position.Höhe", 80)

rahmen_obj_15.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_ControlValve.Text",
    "'NC3304'")

rahmen_obj_15.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_ControlValve.AOUT",
    "N3304")

# --- Rahmen 17 wird hinzugefügt: SBL_Valve ---
rahmen_ref_16 = visu.create_frame_reference("AutomationLibrary2.SBL_Valve")
rahmen_obj_16 = elementlist.add_element(VisualElementType.Frame)
rahmen_obj_16.set_frame_references([rahmen_ref_16])

rahmen_obj_16.set_property("Position.X", 535)
rahmen_obj_16.set_property("Position.Y", 995)
rahmen_obj_16.set_property("Position.Breite", 85)
rahmen_obj_16.set_property("Position.Höhe", 60)

rahmen_obj_16.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.Text",
    "'YS3305'")

rahmen_obj_16.set_property(
    "Referenzierte Visualisierungen.AutomationLibrary2.SBL_Valve.IDF",
    "Y3305")

# --- Start-Schaltfläche wird hinzugefügt ---
start_button = elementlist.add_element(VisualElementType.Ellipse)
start_button.set_property("Position.X", 125)
start_button.set_property("Position.Y", 20)
start_button.set_property("Position.Breite", 50)
start_button.set_property("Position.Höhe", 50)
start_button.set_property("Farben.Normalzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Normalzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Rahmenfarbe.Transparenz", 255)
start_button.set_property("Farben.Alarmzustand.Füllfarbe.Transparenz", 255)
start_button.set_property("Aussehen.Linienstärke", 1)
start_button.set_property("Aussehen.Füllart", "Ausgefüllt")
start_button.set_property("Aussehen.Linienart", "Durchgezogen")
start_button.set_property("Texte.Text", "Start")
start_button.set_property("Farbvariablen.Farbumschlag", "Ablauf.Start")
start_button.set_property("Eingabekonfiguration.Tasten.Variable", "Ablauf.Start")

visu.end_modify()

print("HMI erfolgreich mit mehreren Rahmen und Start-Schaltfläche im Projekt erzeugt.")
print("Hinweis: das Projekt wurde NICHT automatisch gespeichert.")
